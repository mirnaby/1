export type Category = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  emoji: string;
};

export type CategoryWithCount = Category & { productCount: number };

export type Product = {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  compareAtPrice: number | null;
  stock: number;
  emoji: string;
  gradientFrom: string;
  gradientTo: string;
  rating: number;
  reviewsCount: number;
  featured: boolean;
  categoryId: string;
  createdAt: Date;
  updatedAt: Date;
};

export type ProductWithCategory = Product & { category: Category };

export type OrderStatus =
  | "PENDING"
  | "PROCESSING"
  | "SHIPPED"
  | "DELIVERED"
  | "CANCELLED";

export type OrderItem = {
  productId: string;
  name: string;
  emoji: string;
  gradientFrom: string;
  gradientTo: string;
  price: number;
  quantity: number;
};

export type Order = {
  id: string;
  orderNumber: string;
  customerId: string;
  status: OrderStatus;
  total: number;
  items: OrderItem[];
  createdAt: Date;
  updatedAt: Date;
};

export type Customer = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  city: string | null;
  address: string | null;
  createdAt: Date;
};

export type OrderWithCustomer = Order & { customer: Customer };
