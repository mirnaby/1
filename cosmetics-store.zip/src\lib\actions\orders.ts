"use server";

import { db, Timestamp } from "@/lib/firebase";
import { FieldValue } from "firebase-admin/firestore";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import type { OrderStatus } from "@/lib/types";
import { getProductById } from "@/lib/data";

export async function placeOrder(formData: FormData) {
  const name = String(formData.get("name") ?? "").trim();
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const phone = String(formData.get("phone") ?? "").trim();
  const city = String(formData.get("city") ?? "").trim();
  const address = String(formData.get("address") ?? "").trim();
  const itemsJson = String(formData.get("items") ?? "[]");

  if (!name || !email) throw new Error("الرجاء تعبئة البيانات المطلوبة");

  const requestedItems: { productId: string; quantity: number }[] = JSON.parse(itemsJson);
  if (requestedItems.length === 0) throw new Error("السلة فارغة");

  const orderItemsData = [];
  let total = 0;

  for (const { productId, quantity } of requestedItems) {
    const product = await getProductById(productId);
    if (!product) throw new Error("منتج غير موجود");
    orderItemsData.push({
      productId: product.id,
      name: product.name,
      emoji: product.emoji,
      gradientFrom: product.gradientFrom,
      gradientTo: product.gradientTo,
      price: product.price,
      quantity,
    });
    total += product.price * quantity;
  }

  const now = Timestamp.now();
  const customerRef = db.collection("customers").doc(email);
  const existingCustomer = await customerRef.get();
  await customerRef.set(
    {
      name,
      email,
      phone: phone || null,
      city: city || null,
      address: address || null,
      createdAt: existingCustomer.exists ? existingCustomer.data()!.createdAt : now,
    },
    { merge: true }
  );

  const orderNumber = `ORD-${Date.now().toString().slice(-8)}`;
  await db.collection("orders").add({
    orderNumber,
    customerId: email,
    status: "PENDING",
    total: Math.round(total * 100) / 100,
    items: orderItemsData,
    createdAt: now,
    updatedAt: now,
  });

  await Promise.all(
    orderItemsData.map((item) =>
      db
        .collection("products")
        .doc(item.productId)
        .update({ stock: FieldValue.increment(-item.quantity) })
    )
  );

  revalidatePath("/admin");
  redirect(`/order-confirmation/${orderNumber}`);
}

export async function updateOrderStatus(orderId: string, formData: FormData) {
  const status = String(formData.get("status") ?? "") as OrderStatus;
  const validStatuses: OrderStatus[] = [
    "PENDING",
    "PROCESSING",
    "SHIPPED",
    "DELIVERED",
    "CANCELLED",
  ];
  if (!validStatuses.includes(status)) {
    throw new Error("حالة غير صالحة");
  }

  await db
    .collection("orders")
    .doc(orderId)
    .update({ status, updatedAt: Timestamp.now() });

  revalidatePath("/admin/orders");
  revalidatePath(`/admin/orders/${orderId}`);
  revalidatePath("/admin");
}
